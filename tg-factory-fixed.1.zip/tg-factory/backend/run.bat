@echo off
REM Helper script - actually starts the backend. Called by start.bat.
cd /d %~dp0
call venv\Scripts\activate.bat
uvicorn app.main:app --reload --port 8000
