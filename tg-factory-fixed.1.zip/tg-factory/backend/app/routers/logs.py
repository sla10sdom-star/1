from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.log import EventLog, LogLevel
from app.schemas.log import EventLogOut

router = APIRouter(prefix="/api/logs", tags=["logs"])


@router.get("", response_model=list[EventLogOut])
def list_logs(
    level: LogLevel | None = None,
    source: str | None = None,
    account_id: int | None = None,
    limit: int = 200,
    db: Session = Depends(get_db),
):
    q = db.query(EventLog)
    if level:
        q = q.filter(EventLog.level == level)
    if source:
        q = q.filter(EventLog.source == source)
    if account_id:
        q = q.filter(EventLog.account_id == account_id)
    return q.order_by(EventLog.created_at.desc()).limit(min(limit, 1000)).all()
