"""
Settings tab backend: a read-only summary of whether the required
Telegram API credentials are configured, so operators can confirm setup
without ever being shown the actual values.
"""
from fastapi import APIRouter
from app.config import get_settings
from app.schemas.setting import RuntimeConfigOut

router = APIRouter(prefix="/api/settings", tags=["settings"])
settings = get_settings()


@router.get("/runtime-config", response_model=RuntimeConfigOut)
def runtime_config():
    return RuntimeConfigOut(
        telegram_api_configured=bool(settings.TELEGRAM_API_ID and settings.TELEGRAM_API_HASH),
    )
