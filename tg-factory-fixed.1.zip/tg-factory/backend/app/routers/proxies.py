"""
Proxy pool utilities. This does NOT talk to Telegram - it's a plain TCP
reachability check against host:port for each pasted proxy, so the UI can
show which proxies are even alive before they get assigned to accounts.
Assigning a proxy to an account still goes through the existing
PATCH /api/telegram/accounts/{id} endpoint.
"""
import asyncio
from pydantic import BaseModel

from fastapi import APIRouter

router = APIRouter(prefix="/api/telegram/proxies", tags=["telegram-proxies"])

CHECK_TIMEOUT_SECONDS = 5


class ProxyCheckRequest(BaseModel):
    proxies: list[str]


class ProxyCheckResult(BaseModel):
    proxy: str
    ok: bool
    error: str | None = None


class ProxyCheckResponse(BaseModel):
    results: list[ProxyCheckResult]


def _split_host_port(proxy: str) -> tuple[str, int] | None:
    # Accepts "scheme://user:pass@host:port", "scheme://host:port", or "host:port".
    rest = proxy.split("://", 1)[-1]
    rest = rest.split("@")[-1]
    if ":" not in rest:
        return None
    host, _, port_str = rest.rpartition(":")
    try:
        return host, int(port_str)
    except ValueError:
        return None


async def _check_one(proxy: str) -> ProxyCheckResult:
    parsed = _split_host_port(proxy.strip())
    if not parsed:
        return ProxyCheckResult(proxy=proxy, ok=False, error="Could not parse host:port")
    host, port = parsed
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=CHECK_TIMEOUT_SECONDS
        )
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        return ProxyCheckResult(proxy=proxy, ok=True)
    except Exception as exc:  # noqa: BLE001
        return ProxyCheckResult(proxy=proxy, ok=False, error=str(exc) or type(exc).__name__)


@router.post("/check", response_model=ProxyCheckResponse)
async def check_proxies(payload: ProxyCheckRequest):
    """Best-effort TCP connect test for each proxy string. This confirms the
    proxy host:port is reachable, not that the full SOCKS5/HTTP handshake or
    Telegram connectivity through it works - that's only verified once a
    proxy is assigned to an account and that account logs in / refreshes."""
    lines = [p for p in payload.proxies if p.strip()]
    results = await asyncio.gather(*(_check_one(p) for p in lines))
    return ProxyCheckResponse(results=list(results))
