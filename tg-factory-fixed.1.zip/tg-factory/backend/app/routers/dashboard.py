"""
Top-level Dashboard summary: account counts by status, and a recent
activity feed pulled from EventLog (login attempts, status checks, etc).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.telegram_account import TelegramAccount, TelegramAccountStatus
from app.models.log import EventLog
from app.schemas.log import EventLogOut

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    total_accounts = db.query(TelegramAccount).count()

    status_counts = {}
    for status in TelegramAccountStatus:
        status_counts[status.value] = db.query(TelegramAccount).filter(
            TelegramAccount.status == status
        ).count()

    recent_logs = db.query(EventLog).order_by(EventLog.created_at.desc()).limit(20).all()

    return {
        "total_accounts": total_accounts,
        "connected_accounts": status_counts.get("connected", 0),
        "account_status_counts": status_counts,
        "recent_activity": [EventLogOut.model_validate(l) for l in recent_logs],
    }
