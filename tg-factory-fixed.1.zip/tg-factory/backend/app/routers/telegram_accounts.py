"""
Telegram account management via the official MTProto login flow
(Telethon): phone number -> confirmation code -> optional 2FA password.
No tdata files are read, copied, or accepted anywhere in this flow.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.telegram_account import TelegramAccount, TelegramAccountStatus
from app.schemas.telegram_account import (
    TelegramAccountCreate, TelegramAccountUpdate, TelegramAccountOut,
    ConfirmCodeRequest, Confirm2FARequest,
)
from app.core.security import encrypt_value, decrypt_value
from app.core.logging import log_event
from app.models.log import LogLevel
from app.services.telegram import client as telegram_client

router = APIRouter(prefix="/api/telegram/accounts", tags=["telegram-accounts"])


@router.get("", response_model=list[TelegramAccountOut])
def list_accounts(db: Session = Depends(get_db)):
    return db.query(TelegramAccount).order_by(TelegramAccount.created_at.desc()).all()


@router.post("", response_model=TelegramAccountOut, status_code=201)
def create_account(payload: TelegramAccountCreate, db: Session = Depends(get_db)):
    account = TelegramAccount(
        label=payload.label,
        phone_number=payload.phone_number,
        proxy_type=payload.proxy_type,
        proxy_host=payload.proxy_host,
        proxy_port=payload.proxy_port,
        proxy_username=payload.proxy_username,
        proxy_password_encrypted=encrypt_value(payload.proxy_password) if payload.proxy_password else None,
        status=TelegramAccountStatus.PENDING_PHONE,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


@router.patch("/{account_id}", response_model=TelegramAccountOut)
def update_account(account_id: int, payload: TelegramAccountUpdate, db: Session = Depends(get_db)):
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")
    data = payload.model_dump(exclude_unset=True)
    if "proxy_password" in data:
        pwd = data.pop("proxy_password")
        account.proxy_password_encrypted = encrypt_value(pwd) if pwd else None
    for k, v in data.items():
        setattr(account, k, v)
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


@router.delete("/{account_id}", status_code=204)
def delete_account(account_id: int, db: Session = Depends(get_db)):
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")
    db.delete(account)
    db.commit()


@router.post("/{account_id}/send-code", response_model=TelegramAccountOut)
async def send_code(account_id: int, db: Session = Depends(get_db)):
    """Step 1: ask Telegram to send a confirmation code to this phone
    number's Telegram app (or SMS as fallback) - the same as opening
    Telegram on a new device and entering your number."""
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")
    try:
        phone_code_hash = await telegram_client.send_login_code(account)
        account.login_phone_code_hash = phone_code_hash
        account.status = TelegramAccountStatus.CODE_SENT
        account.error_message = ""
        db.add(account)
        db.commit()
        db.refresh(account)
        log_event(db, "telegram.login", f"Code sent to account {account.id}", level=LogLevel.INFO)
    except Exception as exc:  # noqa: BLE001
        account.status = TelegramAccountStatus.ERROR
        account.error_message = str(exc)
        db.add(account)
        db.commit()
        log_event(db, "telegram.login", f"send-code failed for account {account.id}: {exc}", level=LogLevel.ERROR)
        raise HTTPException(400, str(exc))
    return account


@router.post("/{account_id}/confirm-code", response_model=TelegramAccountOut)
async def confirm_code(account_id: int, payload: ConfirmCodeRequest, db: Session = Depends(get_db)):
    """Step 2: submit the code the user received in their Telegram app."""
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")
    if account.status != TelegramAccountStatus.CODE_SENT:
        raise HTTPException(400, "Request a code first (send-code) before confirming it")

    try:
        result = await telegram_client.confirm_login_code(account, payload.code)
        if result["status"] == "needs_2fa":
            account.session_encrypted = encrypt_value(result["session"])
            account.status = TelegramAccountStatus.NEEDS_2FA
        else:
            _apply_login_result(account, result)
        db.add(account)
        db.commit()
        db.refresh(account)
        log_event(db, "telegram.login", f"Code confirmed for account {account.id} -> {account.status}", level=LogLevel.INFO)
    except Exception as exc:  # noqa: BLE001
        account.status = TelegramAccountStatus.ERROR
        account.error_message = str(exc)
        db.add(account)
        db.commit()
        log_event(db, "telegram.login", f"confirm-code failed for account {account.id}: {exc}", level=LogLevel.ERROR)
        raise HTTPException(400, str(exc))
    return account


@router.post("/{account_id}/confirm-2fa", response_model=TelegramAccountOut)
async def confirm_2fa(account_id: int, payload: Confirm2FARequest, db: Session = Depends(get_db)):
    """Step 3 (only if the account has a 2FA cloud password set)."""
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")
    if account.status != TelegramAccountStatus.NEEDS_2FA:
        raise HTTPException(400, "This account is not waiting for a 2FA password")

    try:
        partial_session = decrypt_value(account.session_encrypted)
        result = await telegram_client.confirm_2fa_password(account, partial_session, payload.password)
        _apply_login_result(account, result)
        db.add(account)
        db.commit()
        db.refresh(account)
        log_event(db, "telegram.login", f"2FA confirmed for account {account.id}", level=LogLevel.INFO)
    except Exception as exc:  # noqa: BLE001
        account.status = TelegramAccountStatus.ERROR
        account.error_message = str(exc)
        db.add(account)
        db.commit()
        log_event(db, "telegram.login", f"confirm-2fa failed for account {account.id}: {exc}", level=LogLevel.ERROR)
        raise HTTPException(400, str(exc))
    return account


@router.post("/{account_id}/refresh-status", response_model=TelegramAccountOut)
async def refresh_status(account_id: int, db: Session = Depends(get_db)):
    """'Refresh status' button: re-checks the existing session against
    Telegram (does this session still work?) and updates avatar/username/
    name if it does. Does not perform a new login."""
    account = db.get(TelegramAccount, account_id)
    if not account:
        raise HTTPException(404, "Account not found")

    result = await telegram_client.check_status(account)
    account.last_checked_at = datetime.now(timezone.utc)

    if result["status"] == "connected":
        account.status = TelegramAccountStatus.CONNECTED
        account.error_message = ""
        profile = result["profile"]
        account.telegram_user_id = profile["telegram_user_id"]
        account.username = profile["username"]
        account.first_name = profile["first_name"]
        account.last_name = profile["last_name"]
        if profile["avatar_path"]:
            account.avatar_path = profile["avatar_path"]
    elif result["status"] == "invalid":
        account.status = TelegramAccountStatus.INVALID
        account.error_message = result.get("error", "")
    else:
        account.status = TelegramAccountStatus.ERROR
        account.error_message = result.get("error", "")

    db.add(account)
    db.commit()
    db.refresh(account)
    return account


def _apply_login_result(account: TelegramAccount, result: dict) -> None:
    account.session_encrypted = encrypt_value(result["session"])
    account.status = TelegramAccountStatus.CONNECTED
    account.error_message = ""
    profile = result["profile"]
    account.telegram_user_id = profile["telegram_user_id"]
    account.username = profile["username"]
    account.first_name = profile["first_name"]
    account.last_name = profile["last_name"]
    account.avatar_path = profile["avatar_path"]
    account.last_checked_at = datetime.now(timezone.utc)
