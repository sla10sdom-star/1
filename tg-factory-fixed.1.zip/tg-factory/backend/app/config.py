"""
Central application configuration.
Values are loaded from environment variables / .env file.
"""
from functools import lru_cache
from typing import Optional
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="", extra="ignore")

    # --- App ---
    APP_NAME: str = "TG Factory"
    ENV: str = "development"
    SECRET_KEY: str = "change-me-in-production"

    # --- Database ---
    # SQLite for MVP. Swap to postgresql+psycopg2://user:pass@host/db for production.
    DATABASE_URL: str = "sqlite:///./tg_factory.db"

    # --- Telegram (official MTProto login via Telethon) ---
    # Get these at https://my.telegram.org -> API Development Tools.
    # This is the same official mechanism the Telegram Desktop/mobile apps use.
    TELEGRAM_API_ID: Optional[int] = None
    TELEGRAM_API_HASH: Optional[str] = None

    @field_validator("TELEGRAM_API_ID", "TELEGRAM_API_HASH", mode="before")
    @classmethod
    def _blank_env_to_none(cls, value):
        # .env ships with these blank until the user fills them in at
        # https://my.telegram.org - without this, pydantic-settings raises
        # a ValidationError on the empty string and the whole backend process
        # dies on import (before uvicorn ever binds to the port), which is
        # what causes the frontend's "Failed to fetch" error.
        if isinstance(value, str) and value.strip() == "":
            return None
        return value

    # --- Media storage (profile avatars downloaded from Telegram) ---
    MEDIA_ROOT: str = "./media"


@lru_cache
def get_settings() -> "Settings":
    return Settings()
