"""
Application entry point. Wires the database, static media serving (for
downloaded Telegram avatars), CORS, and every feature router into one
FastAPI app.

Run for local dev:
    uvicorn app.main:app --reload --port 8000

In production, replace the startup create_all() with Alembic migrations
and set DATABASE_URL to Postgres.
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import get_settings
from app.database import Base, engine
from app import models  # noqa: F401  (ensures all models are registered before create_all)

from app.routers import dashboard, telegram_accounts, logs, proxies, settings as settings_router

settings = get_settings()

app = FastAPI(title=settings.APP_NAME)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your frontend origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    # MVP: create tables directly. Swap for Alembic migrations before
    # running against a shared/production Postgres database.
    Base.metadata.create_all(bind=engine)


# The media directory must exist before StaticFiles() is instantiated below -
# app.mount() runs at import time, well before the startup event fires.
os.makedirs(settings.MEDIA_ROOT, exist_ok=True)
app.mount("/media", StaticFiles(directory=settings.MEDIA_ROOT), name="media")

for router in (dashboard.router, telegram_accounts.router, logs.router, proxies.router, settings_router.router):
    app.include_router(router)


@app.get("/api/health")
def health():
    return {"status": "ok", "app": settings.APP_NAME}
