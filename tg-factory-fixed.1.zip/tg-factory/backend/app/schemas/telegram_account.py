from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.telegram_account import TelegramAccountStatus


class TelegramAccountCreate(BaseModel):
    label: str
    phone_number: str
    proxy_type: str | None = None
    proxy_host: str | None = None
    proxy_port: int | None = None
    proxy_username: str | None = None
    proxy_password: str | None = None


class TelegramAccountUpdate(BaseModel):
    label: str | None = None
    proxy_type: str | None = None
    proxy_host: str | None = None
    proxy_port: int | None = None
    proxy_username: str | None = None
    proxy_password: str | None = None


class TelegramAccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    label: str
    phone_number: str
    proxy_type: str | None
    proxy_host: str | None
    proxy_port: int | None
    status: TelegramAccountStatus
    error_message: str
    telegram_user_id: str | None
    username: str | None
    first_name: str | None
    last_name: str | None
    avatar_path: str | None
    last_checked_at: datetime | None
    created_at: datetime


class ConfirmCodeRequest(BaseModel):
    code: str


class Confirm2FARequest(BaseModel):
    password: str
