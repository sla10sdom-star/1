from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.log import LogLevel


class EventLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    level: LogLevel
    source: str
    message: str
    context_json: str
    account_id: int | None
    content_item_id: int | None
    created_at: datetime
