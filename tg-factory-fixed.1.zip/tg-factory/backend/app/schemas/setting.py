from pydantic import BaseModel


class RuntimeConfigOut(BaseModel):
    """Non-secret view of what's currently configured - the Settings tab
    uses this to confirm setup without ever exposing the actual values."""
    telegram_api_configured: bool
