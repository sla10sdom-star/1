import enum
from sqlalchemy import Column, Integer, String, Text, DateTime, Enum, func
from app.database import Base


class LogLevel(str, enum.Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class EventLog(Base):
    """Structured application/event log surfaced in the Logs tab.
    Written by every service (AI calls, publishing, scheduler ticks, etc.)."""
    __tablename__ = "event_logs"

    id = Column(Integer, primary_key=True, index=True)
    level = Column(Enum(LogLevel), default=LogLevel.INFO, nullable=False, index=True)
    source = Column(String(120), nullable=False)   # e.g. "pinterest.publish", "ai.text", "scheduler"
    message = Column(Text, nullable=False)
    context_json = Column(Text, default="")        # optional JSON-encoded extra context
    account_id = Column(Integer, nullable=True)
    content_item_id = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
