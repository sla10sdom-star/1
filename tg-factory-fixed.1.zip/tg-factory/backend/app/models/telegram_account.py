import enum
from sqlalchemy import Column, Integer, String, Text, DateTime, Enum, Boolean, func
from app.database import Base


class TelegramAccountStatus(str, enum.Enum):
    PENDING_PHONE = "pending_phone"     # created, phone number set, code not yet requested
    CODE_SENT = "code_sent"             # Telegram sent a login code, waiting for it
    NEEDS_2FA = "needs_2fa"             # code confirmed, account has a 2FA password to enter
    CONNECTED = "connected"             # fully logged in, session valid
    INVALID = "invalid"                 # session expired / revoked / login failed
    ERROR = "error"                     # unexpected error during login or status check


class TelegramAccount(Base):
    """
    A Telegram account connected via the official MTProto login flow
    (phone number + confirmation code, optionally 2FA password) using
    Telethon. No tdata files, no session copying - each account logs in
    the same way the official Telegram app does.
    """
    __tablename__ = "telegram_accounts"

    id = Column(Integer, primary_key=True, index=True)
    label = Column(String(160), nullable=False)          # operator-facing name for this account
    phone_number = Column(String(32), nullable=False)

    # Telethon session, stored as an encrypted StringSession (see core/security.py).
    # This is Telethon's own official session serialization, not a copied tdata folder.
    session_encrypted = Column(Text, nullable=True)

    # Set only transiently during the login flow (not persisted across restarts
    # for security - login must be completed in one sitting).
    login_phone_code_hash = Column(String(120), nullable=True)

    # Proxy for network access (e.g. where Telegram is blocked). Standard
    # MTProto/SOCKS5 proxy config - not tied to any particular account
    # deception, just normal network routing.
    proxy_type = Column(String(16), nullable=True)        # "socks5" | "mtproxy" | "http"
    proxy_host = Column(String(255), nullable=True)
    proxy_port = Column(Integer, nullable=True)
    proxy_username = Column(String(255), nullable=True)
    proxy_password_encrypted = Column(Text, nullable=True)

    status = Column(Enum(TelegramAccountStatus), default=TelegramAccountStatus.PENDING_PHONE, nullable=False)
    error_message = Column(Text, default="")

    telegram_user_id = Column(String(64), nullable=True)
    username = Column(String(160), nullable=True)         # @handle, without the @
    first_name = Column(String(160), nullable=True)
    last_name = Column(String(160), nullable=True)
    avatar_path = Column(String(500), nullable=True)       # downloaded profile photo, served from /media

    last_checked_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
