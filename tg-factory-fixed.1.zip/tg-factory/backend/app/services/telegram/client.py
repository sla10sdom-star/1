"""
Official Telegram login via Telethon (MTProto) - the same protocol and
flow used by Telegram's own desktop/mobile apps: phone number -> Telegram
sends a confirmation code -> optionally a 2FA password -> a session is
established. No tdata folders are read or copied; Telethon manages its
own session serialization (StringSession), which we store encrypted at
rest via core/security.py.

Each function opens a short-lived TelegramClient for one step and
disconnects - there is no persistent background client per account.
"""
import os
import uuid
from typing import Optional

from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError

from app.config import get_settings
from app.core.security import decrypt_value

settings = get_settings()


def _require_app_credentials():
    if not settings.TELEGRAM_API_ID or not settings.TELEGRAM_API_HASH:
        raise RuntimeError(
            "TELEGRAM_API_ID / TELEGRAM_API_HASH are not configured. "
            "Get them at https://my.telegram.org (API Development Tools)."
        )


def _build_proxy_tuple(account) -> Optional[tuple]:
    """Telethon's `proxy` kwarg expects a tuple compatible with PySocks:
    (proxy_type, host, port, rdns, username, password)."""
    if not account.proxy_host or not account.proxy_port:
        return None
    proxy_type_map = {"socks5": 2, "http": 3}  # socks.SOCKS5 / socks.HTTP values
    ptype = proxy_type_map.get((account.proxy_type or "socks5").lower(), 2)
    password = decrypt_value(account.proxy_password_encrypted) if account.proxy_password_encrypted else None
    return (ptype, account.proxy_host, account.proxy_port, True, account.proxy_username, password)


async def send_login_code(account) -> str:
    """Step 1: request a confirmation code from Telegram for this phone
    number. Returns the phone_code_hash needed to confirm the code."""
    _require_app_credentials()
    proxy = _build_proxy_tuple(account)
    client = TelegramClient(StringSession(), settings.TELEGRAM_API_ID, settings.TELEGRAM_API_HASH, proxy=proxy)
    await client.connect()
    try:
        result = await client.send_code_request(account.phone_number)
        return result.phone_code_hash
    finally:
        await client.disconnect()


async def confirm_login_code(account, code: str) -> dict:
    """Step 2: submit the code the user received in Telegram. Returns
    either {"status": "connected", "session": <str>, "profile": {...}}
    or {"status": "needs_2fa"} if the account has a cloud password set."""
    _require_app_credentials()
    proxy = _build_proxy_tuple(account)
    client = TelegramClient(StringSession(), settings.TELEGRAM_API_ID, settings.TELEGRAM_API_HASH, proxy=proxy)
    await client.connect()
    try:
        try:
            await client.sign_in(
                phone=account.phone_number,
                code=code,
                phone_code_hash=account.login_phone_code_hash,
            )
        except SessionPasswordNeededError:
            # Account has 2FA enabled - caller must call confirm_2fa_password next.
            # We keep the connected-but-unauthorized client's session so the
            # password step can reuse it, by returning the session string now.
            return {"status": "needs_2fa", "session": client.session.save()}
        except (PhoneCodeInvalidError, PhoneCodeExpiredError) as exc:
            raise RuntimeError(f"Invalid or expired code: {exc}") from exc

        profile = await _fetch_profile(client)
        return {"status": "connected", "session": client.session.save(), "profile": profile}
    finally:
        await client.disconnect()


async def confirm_2fa_password(account, session_string: str, password: str) -> dict:
    """Step 3 (only if needed): submit the account's 2FA cloud password
    using the partially-authorized session from step 2."""
    _require_app_credentials()
    proxy = _build_proxy_tuple(account)
    client = TelegramClient(StringSession(session_string), settings.TELEGRAM_API_ID, settings.TELEGRAM_API_HASH, proxy=proxy)
    await client.connect()
    try:
        await client.sign_in(password=password)
        profile = await _fetch_profile(client)
        return {"status": "connected", "session": client.session.save(), "profile": profile}
    finally:
        await client.disconnect()


async def check_status(account) -> dict:
    """Re-connect using the stored session and fetch current profile info
    (username/name/avatar) to confirm the session is still valid. This is
    what the 'Refresh status' button calls - it uses the account's own
    already-established session, not a fresh login."""
    _require_app_credentials()
    if not account.session_encrypted:
        return {"status": "invalid", "error": "No session stored yet"}

    session_string = decrypt_value(account.session_encrypted)
    proxy = _build_proxy_tuple(account)
    client = TelegramClient(StringSession(session_string), settings.TELEGRAM_API_ID, settings.TELEGRAM_API_HASH, proxy=proxy)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            return {"status": "invalid", "error": "Session is no longer authorized"}
        profile = await _fetch_profile(client)
        return {"status": "connected", "profile": profile}
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "error": str(exc)}
    finally:
        await client.disconnect()


async def _fetch_profile(client: TelegramClient) -> dict:
    """Fetches basic profile info + downloads the current avatar to disk,
    returning a dict ready to merge into the TelegramAccount row."""
    me = await client.get_me()
    avatar_path = None
    try:
        avatar_dir = os.path.join(settings.MEDIA_ROOT, "avatars")
        os.makedirs(avatar_dir, exist_ok=True)
        filename = f"{uuid.uuid4().hex}.jpg"
        full_path = os.path.join(avatar_dir, filename)
        downloaded = await client.download_profile_photo(me, file=full_path)
        if downloaded:
            avatar_path = downloaded
    except Exception:
        avatar_path = None  # profile photo download failing shouldn't block login

    return {
        "telegram_user_id": str(me.id),
        "username": me.username,
        "first_name": me.first_name,
        "last_name": me.last_name,
        "avatar_path": avatar_path,
    }
