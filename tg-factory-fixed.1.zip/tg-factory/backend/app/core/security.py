"""
Symmetric encryption for OAuth tokens at rest, using Fernet (AES-128-CBC +
HMAC) derived from SECRET_KEY. This is intentionally simple - for a
production multi-tenant deployment, swap this for a KMS-backed envelope
encryption scheme.
"""
import base64
import hashlib
from cryptography.fernet import Fernet
from app.config import get_settings

settings = get_settings()


def _fernet() -> Fernet:
    key = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
    return Fernet(base64.urlsafe_b64encode(key))


def encrypt_value(plain: str) -> str:
    return _fernet().encrypt(plain.encode()).decode()


def decrypt_value(token: str) -> str:
    return _fernet().decrypt(token.encode()).decode()
