"""
Writes structured events into the event_logs table so the Logs tab and
error-handling flows have a single source of truth (in addition to
whatever stdout logging uvicorn/workers already do).
"""
import json
from sqlalchemy.orm import Session
from app.models.log import EventLog, LogLevel


def log_event(
    db: Session,
    source: str,
    message: str,
    level: LogLevel = LogLevel.INFO,
    account_id: int | None = None,
    content_item_id: int | None = None,
    context: dict | None = None,
) -> EventLog:
    entry = EventLog(
        level=level,
        source=source,
        message=message,
        context_json=json.dumps(context or {}, ensure_ascii=False),
        account_id=account_id,
        content_item_id=content_item_id,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
