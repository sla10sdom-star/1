@echo off
REM Helper script - actually starts the frontend. Called by start.bat.
cd /d %~dp0
npm run dev
