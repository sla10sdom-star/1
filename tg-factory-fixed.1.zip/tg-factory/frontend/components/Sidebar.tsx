"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Send, ScrollText, Settings as SettingsIcon } from "lucide-react";

const NAV_SECTIONS = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Telegram Accounts", href: "/telegram-accounts", icon: Send },
  { label: "Logs", href: "/logs", icon: ScrollText },
  { label: "Settings", href: "/settings", icon: SettingsIcon },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 border-r border-gray-100 bg-white min-h-screen">
      <div className="px-5 py-5 border-b border-gray-100 flex items-center gap-2.5">
        <div className="h-8 w-8 rounded-lg bg-brand flex items-center justify-center shrink-0">
          <Send className="h-4 w-4 text-white" strokeWidth={2.5} />
        </div>
        <div>
          <div className="text-base font-bold text-gray-900 leading-tight">TG Factory</div>
          <div className="text-xs text-gray-400">Telegram Account Manager</div>
        </div>
      </div>
      <nav className="py-3 px-2">
        {NAV_SECTIONS.map((item) => {
          const active = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 mb-0.5 rounded-lg text-sm font-medium transition-colors ${
                active
                  ? "bg-brand-light text-brand"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              }`}
            >
              <Icon className="h-4 w-4 shrink-0" strokeWidth={2} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
