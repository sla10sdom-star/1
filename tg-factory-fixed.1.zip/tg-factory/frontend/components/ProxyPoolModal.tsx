"use client";

import { useMemo, useState } from "react";
import { Users, ShieldCheck, Globe, ClipboardPaste, Trash2, ArrowDownUp, Shuffle, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { api } from "@/lib/api";
import Modal from "./Modal";

type Account = { id: number; label: string };
type CheckResult = { proxy: string; ok: boolean; error: string | null };

function parseLines(raw: string): string[] {
  return raw.split("\n").map((l) => l.trim()).filter(Boolean);
}

function shuffled<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function ProxyPoolModal({
  accounts, onClose, onDone,
}: { accounts: Account[]; onClose: () => void; onDone: () => void }) {
  const [raw, setRaw] = useState("");
  const [mode, setMode] = useState<"sequential" | "random">("sequential");
  const [assigning, setAssigning] = useState(false);
  const [checking, setChecking] = useState(false);
  const [results, setResults] = useState<CheckResult[] | null>(null);
  const [message, setMessage] = useState("");

  const proxies = useMemo(() => parseLines(raw), [raw]);
  const checkedOk = results ? results.filter((r) => r.ok).length : 0;

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setRaw((prev) => (prev ? `${prev}\n${text}` : text));
    } catch {
      setMessage("Couldn't read the clipboard - paste manually instead.");
    }
  };

  const clearAll = () => { setRaw(""); setResults(null); setMessage(""); };

  const assignProxies = async () => {
    if (!proxies.length || !accounts.length) return;
    setAssigning(true);
    setMessage("");
    try {
      const order = mode === "random" ? shuffled(accounts) : accounts;
      const jobs = order.map((account, i) => {
        const proxyStr = proxies[i % proxies.length];
        const m = proxyStr.match(/^(?:(\w+):\/\/)?(?:([^:@]+):([^@]+)@)?([^:@\/]+):(\d+)$/);
        if (!m) return Promise.resolve();
        const [, type, user, pass, host, port] = m;
        return api.patch(`/api/telegram/accounts/${account.id}`, {
          proxy_type: type || "socks5",
          proxy_host: host,
          proxy_port: Number(port),
          proxy_username: user || null,
          proxy_password: pass || null,
        });
      });
      await Promise.all(jobs);
      setMessage(`Assigned ${Math.min(proxies.length, accounts.length) > 0 ? accounts.length : 0} account(s) a proxy.`);
      onDone();
    } catch (e: any) {
      setMessage(e.message || "Failed to assign proxies.");
    } finally {
      setAssigning(false);
    }
  };

  const checkAll = async () => {
    if (!proxies.length) return;
    setChecking(true);
    setMessage("");
    try {
      const res = await api.post<{ results: CheckResult[] }>("/api/telegram/proxies/check", { proxies });
      setResults(res.results);
    } catch (e: any) {
      setMessage(e.message || "Failed to check proxies.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <Modal title="Proxy Pool" onClose={onClose} width="max-w-lg" footer={
      <>
        <button onClick={checkAll} disabled={!proxies.length || checking} className="btn-secondary flex items-center gap-2">
          {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          Check all proxies
        </button>
        <button onClick={assignProxies} disabled={!proxies.length || !accounts.length || assigning} className="btn-primary flex items-center gap-2">
          {assigning ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          Assign proxies
        </button>
      </>
    }>
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="border border-gray-100 rounded-xl p-3 text-center">
          <Users className="h-4 w-4 text-gray-400 mx-auto mb-1" />
          <div className="text-lg font-bold text-gray-900">{accounts.length}</div>
          <div className="text-[11px] text-gray-400">Accounts</div>
        </div>
        <div className="border border-gray-100 rounded-xl p-3 text-center">
          <ShieldCheck className="h-4 w-4 text-gray-400 mx-auto mb-1" />
          <div className="text-lg font-bold text-gray-900">{proxies.length}</div>
          <div className="text-[11px] text-gray-400">Proxies</div>
        </div>
        <div className="border border-gray-100 rounded-xl p-3 text-center">
          <Globe className="h-4 w-4 text-gray-400 mx-auto mb-1" />
          <div className="text-lg font-bold text-gray-900">{results ? checkedOk : 0}</div>
          <div className="text-[11px] text-gray-400">Reachable</div>
        </div>
      </div>

      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 mb-3 text-xs font-medium">
        <button onClick={() => setMode("sequential")}
          className={`flex-1 py-1.5 rounded-md transition-colors flex items-center justify-center gap-1.5 ${mode === "sequential" ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
          <ArrowDownUp className="h-3.5 w-3.5" /> Sequential
        </button>
        <button onClick={() => setMode("random")}
          className={`flex-1 py-1.5 rounded-md transition-colors flex items-center justify-center gap-1.5 ${mode === "random" ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
          <Shuffle className="h-3.5 w-3.5" /> Random
        </button>
      </div>

      <textarea
        className="input-field w-full h-32 resize-none font-mono text-xs"
        placeholder={"socks5://user:pass@proxy.example.com:1080\nsocks5://user:pass@ip:port"}
        value={raw}
        onChange={(e) => { setRaw(e.target.value); setResults(null); }}
      />
      <button onClick={pasteFromClipboard} className="btn-secondary text-xs mt-2 flex items-center gap-1.5">
        <ClipboardPaste className="h-3.5 w-3.5" /> Paste from clipboard
      </button>

      {results && (
        <div className="mt-3 max-h-32 overflow-y-auto border border-gray-100 rounded-lg divide-y divide-gray-50">
          {results.map((r, i) => (
            <div key={i} className="flex items-center gap-2 px-3 py-1.5 text-xs">
              {r.ok ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" /> : <XCircle className="h-3.5 w-3.5 text-red-500 shrink-0" />}
              <span className="font-mono text-gray-600 truncate flex-1">{r.proxy}</span>
              {!r.ok && r.error && <span className="text-red-400 truncate max-w-[40%]">{r.error}</span>}
            </div>
          ))}
        </div>
      )}

      <p className="text-xs text-gray-400 mt-3">
        Proxies will be assigned to all accounts ({accounts.length}). To change the proxy on one specific
        account, use its card in the list below.
      </p>
      {message && <p className="text-xs text-gray-600 mt-2">{message}</p>}

      <div className="flex justify-end pb-1 pt-1">
        <button onClick={clearAll} className="text-red-400 hover:text-red-600 text-xs flex items-center gap-1.5">
          <Trash2 className="h-3.5 w-3.5" /> Clear
        </button>
      </div>
    </Modal>
  );
}
