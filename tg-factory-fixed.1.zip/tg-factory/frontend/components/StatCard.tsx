const ACCENTS: Record<string, string> = {
  default: "bg-brand",
  green: "bg-emerald-500",
  amber: "bg-amber-500",
  blue: "bg-blue-500",
};

export default function StatCard({ label, value, sub, accent = "default" }: {
  label: string; value: string | number; sub?: string; accent?: keyof typeof ACCENTS;
}) {
  return (
    <div className="panel relative overflow-hidden">
      <div className={`absolute top-0 left-0 h-1 w-full ${ACCENTS[accent]}`} />
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-3xl font-bold text-gray-900 mt-1.5">{value}</div>
      {sub && <div className="text-xs text-gray-400 mt-1">{sub}</div>}
    </div>
  );
}
