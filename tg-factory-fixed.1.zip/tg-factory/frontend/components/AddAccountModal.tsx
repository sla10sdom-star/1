"use client";

import { useState } from "react";
import { Phone, Shield, ArrowRight, CheckCircle2, Eye, EyeOff, MessageSquare, KeyRound, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import Modal from "./Modal";

type Step = 1 | 2 | 3 | 4;

const STEPS: { step: Step; label: string }[] = [
  { step: 1, label: "Phone number" },
  { step: 2, label: "SMS code" },
  { step: 3, label: "2FA (optional)" },
  { step: 4, label: "Done" },
];

const EMPTY = {
  label: "", phone: "",
  proxyMode: "string" as "string" | "form",
  proxyString: "",
  proxyType: "socks5", proxyHost: "", proxyPort: "", proxyUser: "", proxyPass: "",
};

/** Parses "socks5://user:pass@host:port" or "socks5://host:port" or "host:port". */
function parseProxyString(raw: string) {
  const s = raw.trim();
  if (!s) return null;
  const m = s.match(/^(?:(\w+):\/\/)?(?:([^:@]+):([^@]+)@)?([^:@\/]+):(\d+)$/);
  if (!m) return null;
  const [, type, user, pass, host, port] = m;
  return {
    proxy_type: type || "socks5",
    proxy_host: host,
    proxy_port: Number(port),
    proxy_username: user || null,
    proxy_password: pass || null,
  };
}

export default function AddAccountModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [step, setStep] = useState<Step>(1);
  const [form, setForm] = useState(EMPTY);
  const [accountId, setAccountId] = useState<number | null>(null);
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [successProfile, setSuccessProfile] = useState<{ username: string | null; first_name: string | null } | null>(null);

  // Proxy is optional: only validate it if the user actually entered something.
  const proxyEntered =
    form.proxyMode === "string"
      ? form.proxyString.trim().length > 0
      : form.proxyHost.trim().length > 0 || form.proxyPort.trim().length > 0;

  const proxyValid =
    !proxyEntered ||
    (form.proxyMode === "string"
      ? !!parseProxyString(form.proxyString)
      : !!form.proxyHost.trim() && !!form.proxyPort.trim());

  const canSubmitStep1 = form.phone.trim().length > 3 && proxyValid;

  const submitStep1 = async () => {
    setError("");
    setBusy(true);
    try {
      let proxy: Record<string, unknown> = {
        proxy_type: null, proxy_host: null, proxy_port: null, proxy_username: null, proxy_password: null,
      };
      if (proxyEntered) {
        const parsed = form.proxyMode === "string"
          ? parseProxyString(form.proxyString)
          : (form.proxyHost.trim() && form.proxyPort.trim()
              ? {
                  proxy_type: form.proxyType,
                  proxy_host: form.proxyHost,
                  proxy_port: Number(form.proxyPort),
                  proxy_username: form.proxyUser || null,
                  proxy_password: form.proxyPass || null,
                }
              : null);
        if (!parsed) throw new Error("Enter a valid proxy in host:port format, or clear the field to skip it.");
        proxy = parsed;
      }

      const phone = form.phone.trim().startsWith("+") ? form.phone.trim() : `+${form.phone.trim()}`;
      const account = await api.post<{ id: number }>("/api/telegram/accounts", {
        label: form.label.trim() || phone,
        phone_number: phone,
        ...proxy,
      });
      setAccountId(account.id);
      await api.post(`/api/telegram/accounts/${account.id}/send-code`);
      setStep(2);
    } catch (e: any) {
      setError(e.message || "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  const submitStep2 = async () => {
    if (!accountId || !code.trim()) return;
    setError("");
    setBusy(true);
    try {
      const account = await api.post<{ status: string; username: string | null; first_name: string | null }>(
        `/api/telegram/accounts/${accountId}/confirm-code`, { code: code.trim() }
      );
      if (account.status === "needs_2fa") {
        setStep(3);
      } else {
        setSuccessProfile(account);
        setStep(4);
      }
    } catch (e: any) {
      setError(e.message || "Invalid or expired code.");
    } finally {
      setBusy(false);
    }
  };

  const submitStep3 = async () => {
    if (!accountId || !password) return;
    setError("");
    setBusy(true);
    try {
      const account = await api.post<{ username: string | null; first_name: string | null }>(
        `/api/telegram/accounts/${accountId}/confirm-2fa`, { password }
      );
      setSuccessProfile(account);
      setStep(4);
    } catch (e: any) {
      setError(e.message || "Incorrect 2FA password.");
    } finally {
      setBusy(false);
    }
  };

  const finish = () => { onDone(); onClose(); };

  return (
    <Modal title="Add account" onClose={onClose} width="max-w-lg" footer={
      step === 1 ? (
        <button onClick={submitStep1} disabled={!canSubmitStep1 || busy} className="btn-primary flex items-center gap-2">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          Send SMS code
        </button>
      ) : step === 2 ? (
        <button onClick={submitStep2} disabled={!code.trim() || busy} className="btn-primary flex items-center gap-2">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          Confirm code
        </button>
      ) : step === 3 ? (
        <button onClick={submitStep3} disabled={!password || busy} className="btn-primary flex items-center gap-2">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          Confirm password
        </button>
      ) : (
        <button onClick={finish} className="btn-primary">Done</button>
      )
    }>
      {/* Step indicator */}
      <div className="flex items-center mb-6">
        {STEPS.map((s, i) => (
          <div key={s.step} className="flex items-center flex-1 last:flex-none">
            <div className="flex items-center gap-2 shrink-0">
              <div className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0
                ${step === s.step ? "bg-brand text-white" : step > s.step ? "bg-brand/20 text-brand" : "bg-gray-100 text-gray-400"}`}>
                {step > s.step ? <CheckCircle2 className="h-4 w-4" /> : s.step}
              </div>
              <span className={`text-xs font-medium hidden sm:inline ${step === s.step ? "text-gray-900" : "text-gray-400"}`}>
                {s.label}
              </span>
            </div>
            {i < STEPS.length - 1 && <div className={`h-px flex-1 mx-2 ${step > s.step ? "bg-brand/30" : "bg-gray-100"}`} />}
          </div>
        ))}
      </div>

      {error && <div className="mb-4 text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</div>}

      {step === 1 && (
        <div className="space-y-4 pb-2">
          <div className="border border-dashed border-gray-200 rounded-xl p-4">
            <div className="flex items-start gap-3 mb-3">
              <div className="h-8 w-8 rounded-lg bg-brand/10 flex items-center justify-center shrink-0">
                <Phone className="h-4 w-4 text-brand" />
              </div>
              <div>
                <div className="text-sm font-semibold text-gray-900">Enter the phone number</div>
                <div className="text-xs text-gray-500 mt-0.5">
                  Enter the Telegram phone number with country code (e.g. +12025550123 or 12025550123)
                </div>
              </div>
            </div>
            <input className="input-field w-full" placeholder="+12025550123 or 12025550123"
              value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <p className="text-xs text-gray-400 mt-1.5">The + prefix is optional and will be added automatically.</p>
            <input className="input-field w-full mt-3" placeholder="Label (optional, e.g. Main account)"
              value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
          </div>

          <div className="border border-dashed border-gray-200 rounded-xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-lg bg-brand/10 flex items-center justify-center shrink-0">
                  <Shield className="h-4 w-4 text-brand" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-900">Proxy settings (optional)</div>
                  <div className="text-xs text-gray-500 mt-0.5">Only needed where Telegram is network-blocked</div>
                </div>
              </div>
              <span className="text-[10px] font-bold tracking-wide text-gray-500 bg-gray-100 px-2 py-1 rounded-full shrink-0">OPTIONAL</span>
            </div>

            <div className="flex gap-1 bg-gray-100 rounded-lg p-1 mb-3 text-xs font-medium">
              <button onClick={() => setForm({ ...form, proxyMode: "string" })}
                className={`flex-1 py-1.5 rounded-md transition-colors ${form.proxyMode === "string" ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
                String format
              </button>
              <button onClick={() => setForm({ ...form, proxyMode: "form" })}
                className={`flex-1 py-1.5 rounded-md transition-colors ${form.proxyMode === "form" ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
                Detailed form
              </button>
            </div>

            {form.proxyMode === "string" ? (
              <>
                <input className="input-field w-full" placeholder="Leave blank to connect without a proxy"
                  value={form.proxyString} onChange={(e) => setForm({ ...form, proxyString: e.target.value })} />
                <p className="text-xs text-gray-400 mt-1.5">
                  Examples: socks5://127.0.0.1:1080 or socks5://user:pass@proxy.example.com:1080
                </p>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Type</label>
                  <select className="input-field w-full" value={form.proxyType}
                    onChange={(e) => setForm({ ...form, proxyType: e.target.value })}>
                    <option value="socks5">socks5</option>
                    <option value="http">http</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Port</label>
                  <input className="input-field w-full" placeholder="1080"
                    value={form.proxyPort} onChange={(e) => setForm({ ...form, proxyPort: e.target.value })} />
                </div>
                <div className="col-span-2">
                  <label className="text-xs text-gray-500 mb-1 block">Host</label>
                  <input className="input-field w-full" placeholder="proxy.example.com"
                    value={form.proxyHost} onChange={(e) => setForm({ ...form, proxyHost: e.target.value })} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Username (optional)</label>
                  <input className="input-field w-full" placeholder="username"
                    value={form.proxyUser} onChange={(e) => setForm({ ...form, proxyUser: e.target.value })} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Password (optional)</label>
                  <div className="relative">
                    <input className="input-field w-full pr-9" type={showPass ? "text" : "password"} placeholder="password"
                      value={form.proxyPass} onChange={(e) => setForm({ ...form, proxyPass: e.target.value })} />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="pb-2">
          <div className="border border-dashed border-gray-200 rounded-xl p-4">
            <div className="flex items-start gap-3 mb-3">
              <div className="h-8 w-8 rounded-lg bg-brand/10 flex items-center justify-center shrink-0">
                <MessageSquare className="h-4 w-4 text-brand" />
              </div>
              <div>
                <div className="text-sm font-semibold text-gray-900">Enter the confirmation code</div>
                <div className="text-xs text-gray-500 mt-0.5">
                  Telegram sent a login code to this account's Telegram app (or SMS).
                </div>
              </div>
            </div>
            <input className="input-field w-full tracking-widest text-center text-lg" placeholder="12345"
              value={code} onChange={(e) => setCode(e.target.value)} autoFocus />
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="pb-2">
          <div className="border border-dashed border-gray-200 rounded-xl p-4">
            <div className="flex items-start gap-3 mb-3">
              <div className="h-8 w-8 rounded-lg bg-brand/10 flex items-center justify-center shrink-0">
                <KeyRound className="h-4 w-4 text-brand" />
              </div>
              <div>
                <div className="text-sm font-semibold text-gray-900">Two-factor password</div>
                <div className="text-xs text-gray-500 mt-0.5">
                  This account has a cloud (2FA) password enabled. Enter it to finish connecting.
                </div>
              </div>
            </div>
            <input className="input-field w-full" type="password" placeholder="2FA password"
              value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="flex flex-col items-center text-center py-6 pb-8">
          <div className="h-14 w-14 rounded-full bg-green-50 flex items-center justify-center mb-4">
            <CheckCircle2 className="h-7 w-7 text-green-500" />
          </div>
          <div className="text-base font-semibold text-gray-900">Account connected</div>
          <div className="text-sm text-gray-500 mt-1">
            {successProfile?.first_name || successProfile?.username
              ? `${successProfile?.first_name || ""}${successProfile?.username ? ` · @${successProfile.username}` : ""}`
              : "The account is now connected."}
          </div>
        </div>
      )}
    </Modal>
  );
}
