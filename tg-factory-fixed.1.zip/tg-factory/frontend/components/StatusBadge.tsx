const COLORS: Record<string, string> = {
  draft: "bg-gray-100 text-gray-600",
  generating: "bg-blue-100 text-blue-700",
  ready: "bg-emerald-100 text-emerald-700",
  scheduled: "bg-amber-100 text-amber-700",
  published: "bg-green-100 text-green-700",
  failed: "bg-red-100 text-red-700",
  active: "bg-green-100 text-green-700",
  pending_auth: "bg-amber-100 text-amber-700",
  token_expired: "bg-red-100 text-red-700",
  disabled: "bg-gray-100 text-gray-600",
  error: "bg-red-100 text-red-700",
};

const DOT_COLORS: Record<string, string> = {
  draft: "bg-gray-400",
  generating: "bg-blue-500",
  ready: "bg-emerald-500",
  scheduled: "bg-amber-500",
  published: "bg-green-500",
  failed: "bg-red-500",
  active: "bg-green-500",
  pending_auth: "bg-amber-500",
  token_expired: "bg-red-500",
  disabled: "bg-gray-400",
  error: "bg-red-500",
};

export default function StatusBadge({ status }: { status: string }) {
  const cls = COLORS[status] || "bg-gray-100 text-gray-600";
  const dot = DOT_COLORS[status] || "bg-gray-400";
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${cls}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      {status.replace(/_/g, " ")}
    </span>
  );
}
