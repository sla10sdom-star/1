"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import PageHeader from "@/components/PageHeader";

type LogEntry = {
  id: number; level: string; source: string; message: string;
  account_id: number | null; created_at: string;
};

const LEVEL_COLORS: Record<string, string> = {
  info: "bg-blue-100 text-blue-700",
  warning: "bg-amber-100 text-amber-700",
  error: "bg-red-100 text-red-700",
};

export default function LogsPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [level, setLevel] = useState("");

  const load = () => {
    const qs = level ? `?level=${level}` : "";
    api.get<LogEntry[]>(`/api/logs${qs}`).then(setLogs).catch(() => {});
  };
  useEffect(() => { load(); }, [level]);

  return (
    <div>
      <PageHeader title="Logs" description="Structured events from every service — AI calls, publishing, sync jobs — for debugging and error handling." />

      <div className="flex gap-2 mb-4">
        {["", "info", "warning", "error"].map((l) => (
          <button key={l} onClick={() => setLevel(l)}
            className={`pill-tab capitalize ${level === l ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-600"}`}>
            {l || "All"}
          </button>
        ))}
      </div>

      <div className="panel-flush divide-y divide-gray-100">
        {logs.map((l) => (
          <div key={l.id} className="px-4 py-3 flex items-start gap-3 hover:bg-gray-50 transition-colors">
            <span className={`shrink-0 text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full mt-0.5 ${LEVEL_COLORS[l.level]}`}>
              {l.level}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-sm text-gray-800">{l.message}</div>
              <div className="text-xs text-gray-400 mt-0.5">
                {l.source} {l.account_id ? `· account #${l.account_id}` : ""} · {new Date(l.created_at).toLocaleString()}
              </div>
            </div>
          </div>
        ))}
        {logs.length === 0 && <div className="px-4 py-8 text-center text-gray-400 text-sm">No logs yet.</div>}
      </div>
    </div>
  );
}
