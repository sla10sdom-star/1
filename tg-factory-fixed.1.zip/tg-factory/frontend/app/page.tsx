"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";

type Summary = {
  total_accounts: number;
  connected_accounts: number;
  account_status_counts: Record<string, number>;
  recent_activity: { id: number; level: string; source: string; message: string; created_at: string }[];
};

export default function DashboardPage() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<Summary>("/api/dashboard/summary")
      .then(setSummary)
      .catch((e) => setError(String(e)));
  }, []);

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Overview across all connected Telegram accounts."
      />

      {error && (
        <div className="mb-6 rounded-lg bg-red-50 text-red-700 text-sm px-4 py-3 border border-red-100">
          Could not reach the backend API ({error}). Make sure it's running on the URL set in
          NEXT_PUBLIC_API_BASE.
        </div>
      )}

      {summary && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <StatCard label="Total Accounts" value={summary.total_accounts} accent="default" />
            <StatCard label="Connected" value={summary.connected_accounts} accent="green" />
            <StatCard label="Awaiting Code / 2FA" value={
              (summary.account_status_counts.code_sent ?? 0) + (summary.account_status_counts.needs_2fa ?? 0)
            } accent="amber" />
            <StatCard label="Invalid / Error" value={
              (summary.account_status_counts.invalid ?? 0) + (summary.account_status_counts.error ?? 0)
            } accent="blue" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="panel">
              <h2 className="font-semibold text-gray-900 mb-4">Account Status Breakdown</h2>
              <div className="space-y-2">
                {Object.entries(summary.account_status_counts).map(([status, count]) => (
                  <div key={status} className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 capitalize">{status.replace(/_/g, " ")}</span>
                    <span className="font-medium text-gray-900">{count}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="panel">
              <h2 className="font-semibold text-gray-900 mb-4">Recent Activity</h2>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {summary.recent_activity.length === 0 && (
                  <p className="text-sm text-gray-400">No activity yet.</p>
                )}
                {summary.recent_activity.map((log) => (
                  <div key={log.id} className="text-sm border-b border-gray-50 pb-2 last:border-0">
                    <div className="text-gray-800">{log.message}</div>
                    <div className="text-xs text-gray-400">
                      {log.source} · {new Date(log.created_at).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
