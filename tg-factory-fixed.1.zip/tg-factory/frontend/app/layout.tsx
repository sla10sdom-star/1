import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Sidebar from "@/components/Sidebar";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "TG Factory",
  description: "Telegram account manager — connect and monitor accounts via the official login flow",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="flex font-sans antialiased text-gray-900">
        <Sidebar />
        <main className="flex-1 p-8 max-w-[1400px]">{children}</main>
      </body>
    </html>
  );
}
