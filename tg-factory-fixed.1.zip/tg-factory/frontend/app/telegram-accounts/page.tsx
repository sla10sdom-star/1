"use client";

import { useEffect, useState } from "react";
import { api, API_BASE } from "@/lib/api";
import PageHeader from "@/components/PageHeader";
import AddAccountModal from "@/components/AddAccountModal";
import ProxyPoolModal from "@/components/ProxyPoolModal";
import { RefreshCw, User, Plus, Shield } from "lucide-react";

type Account = {
  id: number;
  label: string;
  phone_number: string;
  proxy_type: string | null;
  proxy_host: string | null;
  proxy_port: number | null;
  status: string;
  error_message: string;
  telegram_user_id: string | null;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  avatar_path: string | null;
  last_checked_at: string | null;
};

const STATUS_COLORS: Record<string, string> = {
  pending_phone: "bg-gray-100 text-gray-600",
  code_sent: "bg-amber-100 text-amber-700",
  needs_2fa: "bg-amber-100 text-amber-700",
  connected: "bg-green-100 text-green-700",
  invalid: "bg-red-100 text-red-700",
  error: "bg-red-100 text-red-700",
};

export default function TelegramAccountsPage() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [codeInputs, setCodeInputs] = useState<Record<number, string>>({});
  const [passwordInputs, setPasswordInputs] = useState<Record<number, string>>({});
  const [actionBusy, setActionBusy] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showProxyPool, setShowProxyPool] = useState(false);

  const load = () => api.get<Account[]>("/api/telegram/accounts").then(setAccounts).catch(() => {});
  useEffect(() => { load(); }, []);

  const sendCode = async (id: number) => {
    setActionBusy(id);
    try {
      await api.post(`/api/telegram/accounts/${id}/send-code`);
      load();
    } finally {
      setActionBusy(null);
    }
  };

  const confirmCode = async (id: number) => {
    const code = codeInputs[id];
    if (!code) return;
    setActionBusy(id);
    try {
      await api.post(`/api/telegram/accounts/${id}/confirm-code`, { code });
      load();
    } finally {
      setActionBusy(null);
    }
  };

  const confirm2FA = async (id: number) => {
    const password = passwordInputs[id];
    if (!password) return;
    setActionBusy(id);
    try {
      await api.post(`/api/telegram/accounts/${id}/confirm-2fa`, { password });
      load();
    } finally {
      setActionBusy(null);
    }
  };

  const refreshStatus = async (id: number) => {
    setActionBusy(id);
    try {
      await api.post(`/api/telegram/accounts/${id}/refresh-status`);
      load();
    } finally {
      setActionBusy(null);
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this Telegram account?")) return;
    await api.delete(`/api/telegram/accounts/${id}`);
    load();
  };

  const avatarUrl = (path: string | null) =>
    path ? `${API_BASE}/media/${path.split("/media/").pop()}` : null;

  return (
    <div>
      <PageHeader
        title="Telegram Accounts"
        description="Connect Telegram accounts via the standard login flow (phone number + confirmation code, official MTProto/Telethon) — the same way the Telegram app itself logs in."
        action={
          <div className="flex items-center gap-2">
            <button onClick={() => setShowProxyPool(true)} className="btn-secondary flex items-center gap-1.5">
              <Shield className="h-4 w-4" /> Proxy Pool
            </button>
            <button onClick={() => setShowAddModal(true)} className="btn-primary flex items-center gap-1.5">
              <Plus className="h-4 w-4" /> Add account
            </button>
          </div>
        }
      />

      <div className="space-y-3">
        {accounts.map((a) => (
          <div key={a.id} className="panel flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden shrink-0">
              {avatarUrl(a.avatar_path) ? (
                <img src={avatarUrl(a.avatar_path)!} alt="" className="h-full w-full object-cover" />
              ) : (
                <User className="h-6 w-6 text-gray-400" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-gray-900">{a.label}</span>
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[a.status] || "bg-gray-100 text-gray-600"}`}>
                  {a.status.replace(/_/g, " ")}
                </span>
              </div>
              <div className="text-sm text-gray-500 mt-0.5">
                {a.first_name || a.last_name ? `${a.first_name || ""} ${a.last_name || ""}`.trim() : a.phone_number}
                {a.username && <span className="text-gray-400"> · @{a.username}</span>}
              </div>
              {a.error_message && <div className="text-xs text-red-500 mt-1">{a.error_message}</div>}

              {a.status === "code_sent" && (
                <div className="flex gap-2 mt-2">
                  <input className="input-field text-sm w-40" placeholder="Enter code"
                    value={codeInputs[a.id] || ""}
                    onChange={(e) => setCodeInputs({ ...codeInputs, [a.id]: e.target.value })} />
                  <button onClick={() => confirmCode(a.id)} disabled={actionBusy === a.id} className="btn-secondary text-sm">
                    Confirm code
                  </button>
                </div>
              )}
              {a.status === "needs_2fa" && (
                <div className="flex gap-2 mt-2">
                  <input className="input-field text-sm w-40" type="password" placeholder="2FA password"
                    value={passwordInputs[a.id] || ""}
                    onChange={(e) => setPasswordInputs({ ...passwordInputs, [a.id]: e.target.value })} />
                  <button onClick={() => confirm2FA(a.id)} disabled={actionBusy === a.id} className="btn-secondary text-sm">
                    Confirm password
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {a.status === "pending_phone" && (
                <button onClick={() => sendCode(a.id)} disabled={actionBusy === a.id} className="btn-primary text-sm">
                  Send code
                </button>
              )}
              {(a.status === "connected" || a.status === "invalid" || a.status === "error") && (
                <button onClick={() => refreshStatus(a.id)} disabled={actionBusy === a.id}
                  className="flex items-center gap-1.5 text-gray-500 text-xs font-medium hover:text-gray-900">
                  <RefreshCw className={`h-3.5 w-3.5 ${actionBusy === a.id ? "animate-spin" : ""}`} />
                  Refresh status
                </button>
              )}
              <button onClick={() => remove(a.id)} className="text-red-500 text-xs font-medium hover:text-red-700">
                Delete
              </button>
            </div>
          </div>
        ))}
        {accounts.length === 0 && (
          <div className="panel text-center text-gray-400 py-12 text-sm">No Telegram accounts yet.</div>
        )}
      </div>

      {showAddModal && (
        <AddAccountModal onClose={() => setShowAddModal(false)} onDone={load} />
      )}
      {showProxyPool && (
        <ProxyPoolModal
          accounts={accounts.map((a) => ({ id: a.id, label: a.label }))}
          onClose={() => setShowProxyPool(false)}
          onDone={load}
        />
      )}
    </div>
  );
}
