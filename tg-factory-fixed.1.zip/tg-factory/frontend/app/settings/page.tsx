"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import PageHeader from "@/components/PageHeader";

type RuntimeConfig = {
  telegram_api_configured: boolean;
};

function ConfigRow({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between text-sm py-2 border-b border-gray-50 last:border-0">
      <span className="text-gray-700">{label}</span>
      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${ok ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
        {ok ? "Configured" : "Not set"}
      </span>
    </div>
  );
}

export default function SettingsPage() {
  const [config, setConfig] = useState<RuntimeConfig | null>(null);

  useEffect(() => {
    api.get<RuntimeConfig>("/api/settings/runtime-config").then(setConfig).catch(() => {});
  }, []);

  return (
    <div>
      <PageHeader
        title="Settings"
        description="Telegram API credentials, required for logging in any account. Secrets are set via environment variables (.env) — this view only confirms what's active."
      />

      {config && (
        <div className="panel max-w-md">
          <h2 className="font-semibold text-gray-900 mb-3">Telegram API</h2>
          <ConfigRow label="TELEGRAM_API_ID / TELEGRAM_API_HASH" ok={config.telegram_api_configured} />
          <p className="text-xs text-gray-400 mt-3">
            Get these at{" "}
            <a href="https://my.telegram.org" target="_blank" rel="noopener noreferrer" className="text-brand hover:underline">
              my.telegram.org
            </a>{" "}
            → API Development Tools, then add them to backend/.env as TELEGRAM_API_ID and
            TELEGRAM_API_HASH, and restart the backend.
          </p>
        </div>
      )}
    </div>
  );
}
