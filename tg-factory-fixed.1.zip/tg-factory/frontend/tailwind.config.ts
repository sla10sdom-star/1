import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          light: "#D9F1FC",
          DEFAULT: "#229ED9", // Telegram blue, used for actions/accents
          dark: "#1A7AAE",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(17, 24, 39, 0.04), 0 1px 3px rgba(17, 24, 39, 0.06)",
        "card-hover": "0 4px 12px rgba(17, 24, 39, 0.08)",
      },
    },
  },
  plugins: [],
};
export default config;
