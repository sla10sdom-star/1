@echo off
REM One-time setup: creates the Python virtual environment, installs all
REM backend and frontend dependencies, and copies the .env templates.
REM Run this once after unzipping the project. After this, use start.bat
REM every time you want to open the dashboard.

echo ============================================
echo   TG Factory - First-time setup
echo ============================================
echo.

echo [1/4] Setting up backend virtual environment...
cd /d "%~dp0backend"
py -m venv venv
if errorlevel 1 (
    echo.
    echo ERROR: Python was not found via the "py" launcher.
    echo Install it from https://www.python.org/downloads/
    echo Make sure to check "Add python.exe to PATH" during installation,
    echo which also registers the "py" launcher used by this script.
    pause
    exit /b 1
)

echo [2/4] Installing backend dependencies (this can take a minute)...
call venv\Scripts\activate.bat
pip install -r requirements.txt
if not exist ".env" (
    copy .env.example .env
    echo Created backend\.env - open it and add your API keys when you have them.
)
call venv\Scripts\deactivate.bat

echo [3/4] Installing frontend dependencies (this can take a few minutes)...
cd /d "%~dp0frontend"
call npm install
if not exist ".env.local" (
    copy .env.local.example .env.local
)

echo [4/4] Done.
echo.
echo ============================================
echo   Setup complete! Run start.bat to launch the dashboard.
echo ============================================
pause
