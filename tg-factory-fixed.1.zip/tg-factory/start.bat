@echo off
REM Starts both the backend (FastAPI) and frontend (Next.js), each in their
REM own window, then opens the dashboard in your browser. This launcher
REM window closes itself once both are started - only 2 windows should
REM remain open: "TG Factory - Backend" and "TG Factory - Frontend".
REM Run setup.bat first if you haven't already.

set ROOT=%~dp0

if not exist "%ROOT%backend\venv" (
    echo Backend virtual environment not found - run setup.bat first.
    pause
    exit /b 1
)
if not exist "%ROOT%frontend\node_modules" (
    echo Frontend dependencies not found - run setup.bat first.
    pause
    exit /b 1
)

echo Starting backend on http://localhost:8000 ...
start "TG Factory - Backend" cmd /k "%ROOT%backend\run.bat"

echo Starting frontend on http://localhost:3000 ...
start "TG Factory - Frontend" cmd /k "%ROOT%frontend\run.bat"

echo Waiting for both servers to come up...
timeout /t 8 /nobreak >nul

start http://localhost:3000

echo Done - this window will close automatically.
timeout /t 3 /nobreak >nul
exit
