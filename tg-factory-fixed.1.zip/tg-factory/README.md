# TG Factory

A dashboard for connecting and monitoring Telegram accounts through Telegram's
**official** login flow: phone number -> confirmation code -> optional 2FA
password. No `tdata` folders are read, copied, or accepted anywhere in this
app - each account logs in exactly the way the official Telegram apps do.

## Architecture

```
backend/            FastAPI app
  app/
    models/          SQLAlchemy ORM models: TelegramAccount, EventLog
    schemas/          Pydantic request/response schemas
    routers/          dashboard, telegram_accounts, logs, settings
    services/
      telegram/       Telethon-based login flow (send code / confirm code /
                       confirm 2FA / check status) - see client.py
    core/             Encryption for stored sessions/proxy passwords,
                       structured event logging
frontend/            Next.js 14 (App Router) + TypeScript + Tailwind
  app/
    page.tsx           Dashboard - account status breakdown + activity feed
    telegram-accounts/ Add accounts, send/confirm code, confirm 2FA,
                       refresh status, shows avatar/@username/name
    logs/              Structured event feed (login attempts, status checks)
    settings/          Confirms whether TELEGRAM_API_ID/HASH are configured
  components/          Sidebar, StatCard, StatusBadge, PageHeader
  lib/api.ts            Typed fetch wrapper around the backend
docker-compose.yml    Postgres + backend + frontend
```

## How Telegram accounts connect

1. Get your own `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` at
   https://my.telegram.org -> API Development Tools. This is the same
   official credential every Telegram client (including Telethon-based
   ones) must use - it identifies the *application*, not any specific user.
2. Add them to `backend/.env`.
3. In the dashboard, go to **Telegram Accounts -> Add account**, enter a
   label and phone number (proxy is optional, only needed where Telegram
   is network-blocked).
4. Click **Send code** - Telegram delivers a confirmation code to that
   phone number's Telegram app (or SMS).
5. Enter the code. If the account has a cloud (2FA) password set, you'll
   be asked for that next.
6. Once connected, the account's avatar, `@username`, and name are shown.
   Click **Refresh status** any time to re-check that the session is still
   valid and pull the latest profile info - this reuses the account's own
   already-established session, it does not perform a new login.

## Running locally

### Easiest way (Windows): two double-click scripts

1. Unzip the project.
2. Double-click **`setup.bat`** once — it creates the Python virtual environment,
   installs backend and frontend dependencies, and copies both `.env` templates.
3. From then on, double-click **`start.bat`** any time you want to open the
   dashboard. It launches the backend and frontend each in their own window
   and opens http://localhost:3000 automatically. The launcher window itself
   closes on its own after a few seconds.

You'll still need to edit `backend\.env` yourself to add `TELEGRAM_API_ID` and
`TELEGRAM_API_HASH` — `setup.bat` only creates the file from the template, it
can't fill in credentials for you.

### Manual way (any OS)

#### 1. Backend
```bash
cd backend
cp .env.example .env
py -m venv venv && venv\Scripts\Activate.ps1   # Windows
# python -m venv venv && source venv/bin/activate  # macOS/Linux
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Visit http://localhost:8000/docs for the interactive API explorer.

#### 2. Frontend
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```
Visit http://localhost:3000.

### Or all at once with Docker
```bash
docker compose up --build
```
(Edit `backend/.env` first — docker-compose reads it via `env_file`.)

## What's implemented

Dashboard summary, Telegram account CRUD, the full login flow (send code /
confirm code / confirm 2FA / refresh status), proxy configuration per
account (SOCKS5/HTTP), avatar/username/name display, structured event
logging, and a settings page confirming API credential setup.

## Recommended next steps for production hardening

- Replace `Base.metadata.create_all()` with Alembic migrations before using
  Postgres for real.
- Add auth/login to the dashboard itself if more than one person will use it.
- Add periodic background status checks (e.g. a scheduled job re-running
  "Refresh status" for every connected account) instead of only on manual click.
- Add retries/backoff around Telegram API calls in `services/telegram/client.py`.
